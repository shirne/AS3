Copyrighted � 2013 by Greg McLeod
https://github.com/cleod9

Free to use in any projects without notifying me, nor is credit needed. Just do not re-distribute it under anyone else's name!

-----------------------------------

About Dictionary utility:

A simple typed Dictionary Class. It maps strings to objects of a given type. (To allow any type to be mapped, pass "Object" as the class type instead)

Minimum required classes for using this utility:

com.mcleodgaming.util.Dictionary
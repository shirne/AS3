Copyrighted � 2013 by Greg McLeod
https://github.com/cleod9

Free to use in any projects without notifying me, nor is credit needed. Just do not re-distribute it under anyone else's name!

----------------------------------

About Key utility:

Tool for AS3 to enable AS2-styled keyboard event behavior. Simply call Key.init() to initialize the class, and Key.beginCapture()/Key.endCapture() to start and end the keyboard event listeners respectively. Also included in this class are also all of the Flash key code values so you don't have to look them up.

Minimum required classes for using this utility:

com.mcleodgaming.util.Key